import requests
import csv
import CryptoAlgorithm


"""This function gets the response from the API"""
def get_response():
    response = requests.get("https://api.basecampcrypto.nl/v1/team?key=sxWIr9bn516h7q5n")
    return response

"""This function reads the csv file"""
def get_csvfile(csv_file):
    csv_data = []
    with open(csv_file, mode = "r") as file:
        csv_file = csv.reader(file, delimiter = ";")
        next(csv_file, None)
        for lines in csv_file:
            csv_data.append(lines)
    return csv_data


def main():
    print(*get_csvfile("crypto_daily_prices_365.csv"), sep = "\n")


if __name__ == "__main__":
    main()